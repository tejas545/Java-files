package mavendemo.maven;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context=new ClassPathXmlApplicationContext("stud.xml");
		// TODO Auto-generated method stub
        student s= (student)context.getBean("s1");
        s.display();
        books b=(books)context.getBean("b1");
        b.display();
        
    }
}
