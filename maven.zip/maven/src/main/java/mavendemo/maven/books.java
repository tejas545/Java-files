package mavendemo.maven;

public class books {
	String publisher,price;
	int id;
	
	public books() {
		
	}

	public books(String publisher, String price, int id) {
		super();
		this.publisher = publisher;
		this.price = price;
		this.id = id;
	}

	public void display() {
		// TODO Auto-generated method stub
		System.out.print("id:"+id+", publisher:"+ publisher+", price:"+price);
		
	}
	

}
