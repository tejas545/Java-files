package JdbcDemoSpring.jdbcdemo;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeOperations {
	JdbcTemplate jdbcTemplate;
	
	 public void setJdbcTemplate(JdbcTemplate jdbcTemplate)
	 {
		 this.jdbcTemplate=jdbcTemplate; 
	 }
	
	
	

	int insert(Emoloyee emp)
	 {
		 
		 String email=emp.getEmail();
		 String name=emp.getName();
		 String id=emp.getId();
		 String salary=emp.getSalary();
		 
		   String query="insert into Emoloyee values('"+email+"','"+id+"','"+name+"','"+salary+"')"; 
		        int result= jdbcTemplate.update(query);
		 
		 return  result;
	 }
	 
}
