package com.example.demo.control;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.mod.Details;
import com.example.demo.serv.StudentService;



@RestController
@RequestMapping("/api")
public class StudentController {
	@Autowired
	StudentService service;
	
	@PostMapping("/details")
	public void saveStudent(@RequestBody Details ee)
	{
		service.saveStudent(ee);
	}
	
	@GetMapping("/Getemployee")
	public List<Details>getAllEmployees()
	{
	return service.getAllDetails();
	}
	
	@PostMapping("/deleteuser/{id}")
	public void deleteStudent(@PathVariable String id)
	{
		service.deleteStudent(id);
	}
	
	@GetMapping("/Getoneemployee/{id}")
	public Optional<Details> getOneEmployees(@PathVariable String id)
	{
	return service.getOneDetails(id);
	}
	
	@PutMapping("/updatestudent/{id}")
	public void updatestudent(@RequestBody Details Student) {
	service.updatestudent(Student);
	}
	
}
