package com.example.demo.serv;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.mod.Details;
import com.example.demo.reposit.StudentRepository;


@Service
public class StudentService {
	@Autowired
	StudentRepository repository;


	public void saveStudent(Details ee) {
		
		repository.save(ee);
	}


	public List<Details> getAllDetails() {
		
		return repository.findAll();
	}


	public void deleteStudent(String id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
		
	}


	public Optional<Details> getOneDetails(String id) {
		// TODO Auto-generated method stub
		return repository.findById(id);
	}




	public void updatestudent(Details student) {
		// TODO Auto-generated method stub
		repository.save(student);
		
	}

}
