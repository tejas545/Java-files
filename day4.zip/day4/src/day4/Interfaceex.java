package day4;

public class Interfaceex {
	public static void main (String args[]) {
		Myclass b=new Myclass();
		b.meth1();
		b.meth2();
	}

}
interface A
{
	void meth1();
	void meth2();
}
class Myclass implements A
{

	
	public void meth1() {
		System.out.println("Method 1 implemented");
	}

	public void meth2() {
		System.out.println("Method 2 implemented");
		
	}
	
}
