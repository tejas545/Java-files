package day4;



public class Interfacevehicle {
	
	public static void main (String args[])
	{
		Motor a=new Motor();
		a.tuneUpCost();
		a.canCarry(2);
	}
	}
interface Ivehicle
{
	public double tuneUpCost();
	public boolean canCarry(int numPassengers);
}


class Motor implements Ivehicle
{

	
	public double tuneUpCost() {
		double bikecost=122000;
		System.out.println("Bike cost is : "+bikecost);
		return 0;
	}

	
	public boolean canCarry(int numPassengers) {
		System.out.println("Number of passengers is: "+numPassengers);
		return false;
	}
	
}




