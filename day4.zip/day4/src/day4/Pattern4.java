package day4;

public class Pattern4 {
	public static void main(String[] args)
	{
	int r=5, num=1;

	for(int i=0; i<r; i++)
	{
	for(int j=0; j<=i; j++)
	System.out.print(num+ " ");

	System.out.print("\n");
	num++;
	}
	}

}
