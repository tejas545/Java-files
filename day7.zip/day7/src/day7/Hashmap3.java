package day7;

import java.util.HashMap;
import java.util.Map;

public class Hashmap3 {
	public static void main(String args[]) {
		
		HashMap<Integer,book> map=new HashMap<>();
		book b1=new book("Java","23","500.Rs");
		book b2=new book("Python","11","400.Rs");
		book b3=new book("PHP","22","300.Rs");
		map.put(1,b1);
		map.put(2,b2);
		map.put(3,b3);
		for(Map.Entry<Integer,book>me:map.entrySet() )
		{
			System.out.println(me.getKey()+" : "+me.getValue());
		}

	}


}
class book
{
	String name,id,price;

	public book(String name, String id, String price) {
		super();
		this.name = name;
		this.id = id;
		this.price = price;
	}
	public String toString()
	{
		return "Name: "+name+" Id: "+id+" Price: "+price;
	}
	
}
