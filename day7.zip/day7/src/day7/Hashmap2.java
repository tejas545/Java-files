package day7;

import java.util.HashMap;
import java.util.Map;

public class Hashmap2 {
public static void main(String args[]) {
		
		HashMap<Integer,String> map=new HashMap<>();
		map.put(1,"Sakshi");
		map.put(2,"xyz");
		map.put(3,"abc");
		map.put(4,"ghj");
		for(Map.Entry<Integer,String>me:map.entrySet() )
		{
			System.out.println(me.getKey()+" : "+me.getValue());
		}

	}

}
