package day7;

import java.util.HashMap;
import java.util.Map;

public class HashmapMethods {
public static void main(String args[]) {
		
		HashMap<Integer,String> map=new HashMap<>();
		map.put(1,"Tejas");
		map.put(2,"xyz");
	
		for(Map.Entry<Integer,String>me:map.entrySet() )
		{
			System.out.println(me.getKey()+" : "+me.getValue());
		}
		System.out.println("Using putAll() method\n");
		HashMap<Integer, String> mp = new HashMap<Integer, String>();
		mp.put(3,"abc");
		mp.put(4,"ghj");
		
		
	    map.putAll(mp);
	    for(Map.Entry<Integer,String> ma:map.entrySet() )
		{
			System.out.println(ma.getKey()+" : "+ma.getValue());
		}
	    
	    
	    
	    

	    System.out.println("Is the key contains 3 present? "+mp.containsKey(3));
	    
	    
	    System.out.println("Using equals() Equality: "+map.equals(mp));
	    
	    
	    
	    System.out.println("Using get() value is: "+map.get(1));
	    
	    
	    
	    System.out.println("Using replace() : ");
	    map.replace(2, "MK");
	    for(Map.Entry<Integer,String>me:map.entrySet() )
		{
			System.out.println(me.getKey()+" : "+me.getValue());
		}
	    
	    
	    
	    System.out.println("Using size() : "+map.size());
	    
	    
	    
	    System.out.println("Using keySet() : "+map.keySet());
	    
	    
	    
	    mp.clear();
	    System.out.println("Using clear() : "+mp);
	    
	    
	    
	    System.out.println("Using isEmpty() : "+mp.isEmpty());
	}
	    
	}

