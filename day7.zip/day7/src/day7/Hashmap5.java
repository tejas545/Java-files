package day7;

import java.util.HashMap;
import java.util.Map;

public class Hashmap5 {
public static void main(String args[]) {
		
		HashMap<Integer,Teacher> map=new HashMap<>();
		Teacher b1=new Teacher("Tejas","23","10th Teacher");
		Teacher b2=new Teacher("Nanda","11","9th Teacher");
		Teacher b3=new Teacher("Ravi","22","8th Teacher");
		map.put(1,b1);
		map.put(2,b2);
		map.put(3,b3);
		for(Map.Entry<Integer,Teacher>me:map.entrySet() )
		{
			System.out.println(me.getKey()+" : "+me.getValue());
		}

	}


}
class Teacher
{
	String name,id,clas;
	public Teacher(String name, String id, String clas) {
		super();
		this.name = name;
		this.id = id;
		this.clas = clas;
	}



	public String toString()
	{
		return "Name: "+name+" Id: "+id+" Class: "+clas;
	}
	
}
