package day7;

import java.util.HashMap;
import java.util.Map;

public class Hashmap {
	public static void main(String args[]) {
		
		HashMap<String,String> map=new HashMap<>();
		map.put("Color1","Red");
		map.put("Color2","Black");
		map.put("Color3","Pink");
		for(Map.Entry<String,String>me:map.entrySet() )
		{
			System.out.println(me.getKey()+" : "+me.getValue());
		}

	}

}
