package day7;

import java.util.HashMap;
import java.util.Map;

public class Hashmap1 {
public static void main(String args[]) {
		
		HashMap<String,Integer> map=new HashMap<>();
		map.put("Anndroid",90);
		map.put("PHP",60);
		map.put("Java",79);
		for(Map.Entry<String,Integer>me:map.entrySet() )
		{
			System.out.println(me.getKey()+" : "+me.getValue());
		}

	}

}
