package day7;

import java.util.HashMap;
import java.util.Map;

public class Hashmap4 {
public static void main(String args[]) {
		
		HashMap<Integer,Employee> map=new HashMap<>();
		Employee b1=new Employee("Tejas","23","50000.Rs");
		Employee b2=new Employee("Nanda","11","40000.Rs");
		Employee b3=new Employee("Ravi","22","30000.Rs");
		map.put(1,b1);
		map.put(2,b2);
		map.put(3,b3);
		for(Map.Entry<Integer,Employee>me:map.entrySet() )
		{
			System.out.println(me.getKey()+" : "+me.getValue());
		}

	}


}
class Employee
{
	String name,id,salary;
	
	
	public Employee(String name, String id, String salary) {
		super();
		this.name = name;
		this.id = id;
		this.salary = salary;
	}


	public String toString()
	{
		return "Name: "+name+" Id: "+id+" Salary: "+salary;
	}
	
}
