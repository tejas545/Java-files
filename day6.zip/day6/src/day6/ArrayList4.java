package day6;

import java.util.ArrayList;

public class ArrayList4 {
	public static void main(String args[])
	{
		ArrayList<stud> list=new ArrayList<>();
		stud s1=new stud("Tejas","Present");
		stud s2=new stud("abc","Absent");
		list.add(s1);
		list.add(s2);
		for(stud a: list)
		{
			System.out.println(a.name+" "+a.attedance);
		}
	}

}
class stud
{
	String name;
	String attedance;
	public stud(String name, String attedance) {
		super();
		this.name = name;
		this.attedance = attedance;
	}
	
	
}