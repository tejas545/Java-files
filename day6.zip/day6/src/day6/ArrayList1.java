package day6;
import java.util.ArrayList;

public class ArrayList1 {
	public static void main(String args[])
	{
		ArrayList<String> list=new ArrayList<>();
		list.add("Tejas");
		list.add("M");
		list.add("K");
		
		for(String x  : list)
        {
        System.out.println(x);    
        }
	}

}
