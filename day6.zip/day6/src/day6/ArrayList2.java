package day6;
import java.util.ArrayList;
public class ArrayList2 {
	public static void main(String args[])
	{
		ArrayList<Integer> list=new ArrayList<>();
		list.add(747);
		list.add(887);
		list.add(5);
		for(int x : list)
		{
			System.out.println(x);
		}
	}

}
