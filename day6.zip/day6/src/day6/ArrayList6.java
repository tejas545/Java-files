package day6;

import java.util.ArrayList;

public class ArrayList6 {
	public static void main(String args[])
	{
		ArrayList<marks> list=new ArrayList<>();
		marks m1=new marks("Tejas ","400/500 ","380/500 ","480/500 ");
		marks m2=new marks("Nanda ","300/500 ","480/500 ","380/500");
		list.add(m1);
		list.add(m2);
		for(marks m:list)
		{
			System.out.println(m.name+m.marks1+m.marks2+m.marks3);
		}
		
	}

}
class marks
{
	String name;
	String marks1;
	String marks2;
	String marks3;
	public marks(String name, String marks1, String marks2, String marks3) {
		super();
		this.name = name;
		this.marks1 = marks1;
		this.marks2 = marks2;
		this.marks3 = marks3;
	}
	
	}
	

