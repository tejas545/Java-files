package day6;

import java.util.ArrayList;

public class ArrayList7 {
	public static void main(String args[])
	{
		ArrayList<book> list=new ArrayList<>();
		book m1=new book("java  ","55  ","500.Rs  ","James ");
		book m2=new book("python  ","10  ","400.Rs  ","Rossum");
		list.add(m1);
		list.add(m2);
		for(book m:list)
		{
			System.out.println(m.name+m.id+m.price+m.author);
		}
		
	}

}
class book
{
	String name;
	String id;
	String price;
	String author;
	public book(String name, String id, String price, String author) {
		super();
		this.name = name;
		this.id = id;
		this.price = price;
		this.author = author;
	}
	
	
}
	