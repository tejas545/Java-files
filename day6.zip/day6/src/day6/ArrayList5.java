package day6;

import java.util.ArrayList;

public class ArrayList5 {
	public static void main(String args[])
	{
		ArrayList<language> list=new ArrayList<>();
		language l1=new language("Java ","9");
		language l2=new language("Android ","8");
		list.add(l1);
		list.add(l2);
		for(language s:list)
		{
			System.out.println(s.subject+s.id);
		}
		
		
		
	}

}
class language
{
	String subject;
	String id;

	public language(String subject, String id) {
		super();
		this.subject = subject;
		this.id = id;
	}
	
}