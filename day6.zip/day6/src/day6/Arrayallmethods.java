package day6;
import java.util.ArrayList;

public class Arrayallmethods {
	public static void main(String args[])
    {
        ArrayList<Integer> arrlist1 = new ArrayList<Integer>(5);
        arrlist1.add(12);
        arrlist1.add(20);
        arrlist1.add(45);
        System.out.println("Printing list1:");
        for (Integer number : arrlist1)
        {
            System.out.println("Number = " + number);     
        }
        ArrayList<Integer> arrlist2 = new ArrayList<Integer>(5);
        arrlist2.add(25);
        arrlist2.add(30);
        arrlist2.add(31);
        arrlist2.add(35);
        System.out.println("Printing list2:");
        
        for (Integer number : arrlist2)
        {
            System.out.println("Number = " + number);
        }
        arrlist1.addAll(arrlist2);
        System.out.println("Printing all the elements");
        for (Integer number : arrlist1) 
            System.out.println("Number = " + number);  
        
        
        //using get
        
        int element =arrlist2.get(2);
        System.out.println("The get element is :"+element);
        
        
        //using remove
        
        arrlist2.remove(1);
        System.out.println("After remove list2 is:");
        
        for (Integer number : arrlist2)
        {
            System.out.println("Number = " + number);
        }
        
        //using removeall
        
        arrlist2.removeAll(arrlist2);
        System.out.println("ArrayList2 after removeAll(): "+arrlist2);
        
        
        
        //using isempty
        
        
        boolean ans=arrlist2.isEmpty();
        if(ans==true)
        {
        	System.out.println("The array list is empty");
        }
        else
        {
        	System.out.println("The array list is not empty");
        }
        
        //using clear
        
        
        arrlist1.clear();
        System.out.println("The array list after using clear() :"+arrlist1);
        
    }
}
	