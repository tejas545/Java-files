package mavendemo.mavenday2;

public class MyMessage {
	public MyMessage()
	{
		System.out.println("Inside constructor");
	}
	void display()
	{
		System.out.println("inside method");
	}

}
