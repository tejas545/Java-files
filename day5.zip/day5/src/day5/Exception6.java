package day5;

public class Exception6 {
	public static void main (String[] args)
	{
	try {
		int a[]=new int[5];
		System.out.println(a[10]);
	}
	catch(ArithmeticException e)
	{
		System.out.println("Arithmetic Exception occurs");
	}
	catch(ArrayIndexOutOfBoundsException e)
	{
		System.out.println("ArrayIndexOutOfBoundsException occurs");
	}
	}

}
