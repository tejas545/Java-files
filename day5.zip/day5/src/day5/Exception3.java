package day5;

public class Exception3 {
	public static void main(String args[])
	{
		try {
			int a[]=new int[2];
			System.out.println(a[5]);
		}
		catch(ArithmeticException e)
		{
			System.out.println("Arithmetic Exception occurs");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("ArrayIndexOutOfBoundsException occurs");
		}
	}

}
