package com.demo;

public class student {
	String name,roll;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRoll() {
		return roll;
	}

	public void setRoll(String roll) {
		this.roll = roll;
	}
	void display()
	{
		System.out.println("Name"+name+"Roll no"+roll);
	}

}
