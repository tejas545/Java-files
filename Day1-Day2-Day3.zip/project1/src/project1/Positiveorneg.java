package project1;
import java.util.Scanner;
public class Positiveorneg {
	public static void main(String args[]) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int number=sc.nextInt();
		if(number>=0) 
		{
			System.out.println("This is a positive number");
		}
		else {
			System.out.println("This is a negative number");
		}

	}


}
