package project1;

import java.util.Scanner;

public class Transaction {
	public static void main (String args[]){
		Balanceenquirey a=new Balanceenquirey();
		a.getAccountNumber();
		a.execute();
		a.execut();

	}

}
class Trans{
	int accountnum;
	 void getAccountNumber()
	{
		 Scanner sc=new Scanner(System.in);
			System.out.println("Enter the Account Number: ");
			accountnum=sc.nextInt();
	}
	 void execute()
	 {
		 System.out.println("Your Account Number is: "+accountnum);
	 }
}
class Balanceenquirey extends Trans
{
	double balance=10000;
	void execut()
	{
		System.out.println("Your Account Balance is: "+balance);
	}
}