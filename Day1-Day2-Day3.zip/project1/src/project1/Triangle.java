package project1;

import java.util.Scanner;
import java.lang.Math;

public class Triangle {
	int l,b,h;
	Triangle()
	{
	System.out.println("Enter the sides of triangle");
	Scanner sc=new Scanner(System.in);

	l=sc.nextInt();
	b=sc.nextInt();
	h=sc.nextInt();
	int p=l+b+h;
	int s2=p/2;
	double sq =(s2*(s2-l)*(s2-b)*(s2-h));
	double area=Math.sqrt(sq);
	System.out.println("Area is: "+area+" Perimeter is: "+p);

	}
	public static void main(String args[]) {
		Triangle a=new Triangle();
	}

}



