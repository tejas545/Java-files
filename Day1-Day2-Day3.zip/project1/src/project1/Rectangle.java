package project1;

public class Rectangle {
	public static void main(String args[])
	{
		int width=20;
		int height=10;
		int area=width*height;
		System.out.println("Area of rectangle is :"+area);
	}

}
