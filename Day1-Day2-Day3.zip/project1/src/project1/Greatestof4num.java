package project1;
import java.util.Scanner;
public class Greatestof4num {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the first number");
		int a=sc.nextInt();
		System.out.println("Enter the second number");
		int b=sc.nextInt();
		System.out.println("Enter the third number");
		int c=sc.nextInt();
		System.out.println("Enter the fourth number");
		int d=sc.nextInt();
		int largest;
		
		if(a>b && a>c && a>d)
		{
			System.out.println("The greatest number is:"+a);
		}
		else if(b>a && b>c && b>d)
		{
			System.out.println("The greatest number is:"+b);
		}
		else if(c>b && c>a && c>d)
		{
			System.out.println("The greatest number is:"+c);
		}
		else if(d>a && d>b && d>c)
		{
			System.out.println("The greatest number is:"+d);
		}

}
}
