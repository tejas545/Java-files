package project1;

import java.util.Scanner;

public class Inheritancehierarchy {
	public static void main (String args[]){
		Mpcmarks a=new Mpcmarks();
		Clcmarks b=new Clcmarks();
		a.ReadDetails();
		a.DisplayDetails();
		a.ReadmpcMarks();
		a.DisplayMpcMarks();
		b.ReadclcMarks();
		b.DisplayclcMarks();
	}

}
class Stud{
	int studentid;
	String studentname,phone;
	void ReadDetails()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the student ID: ");
		studentid=sc.nextInt();
		System.out.println("Enter the student Name: ");
		studentname=sc.next();
		System.out.println("Enter the student phone number: ");
		phone=sc.next();
		
	}
	void DisplayDetails()
	{
		System.out.println("Student name is :"+studentname);
		System.out.println("Student id is :"+studentid);
		System.out.println("Student phone number is :"+phone);
	}
}
class Mpcmarks extends Stud
{
	int m1,m2,m3;
	
	void ReadmpcMarks()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Maths marks: ");
		m1=sc.nextInt();
		System.out.println("Enter the Chemistry marks: ");
		m2=sc.nextInt();
		System.out.println("Enter the physics marks: ");
		m3=sc.nextInt();
	}
	void DisplayMpcMarks()
	{
		System.out.println("\n"+studentname+" marks are:\nMaths:"+m1+"\nChemistry:"+m2+"\nPhysics:"+m3);
	}
	
}



class Clcmarks extends Stud
{
	int m1,m2,m3;
	
	void ReadclcMarks()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Commerce marks: ");
		m1=sc.nextInt();
		System.out.println("Enter the Economics marks: ");
		m2=sc.nextInt();
		System.out.println("Enter the CMCs marks: ");
		m3=sc.nextInt();
	}
	void DisplayclcMarks()
	{
		System.out.println("\n"+studentname+" marks are:\nCommerce:"+m1+"\nEconomics:"+m2+"\nCMCs:"+m3);
	}
	
}




