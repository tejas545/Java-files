package project1;

public class Evennumusingwhile {
	public static void main(String args[]) {
		int sum=0,num=1,count=0,n=10;
			while(count<n) {
				if(num%2==0)
				{
					sum +=num;
					count++;
				}
				num++;
			}
			System.out.println("sum:"+sum);
	}
}
