package project1;

public class Constructorname {
	String name;
	public static void main (String args[]){
		Main obj=new Main("Tejas");
		
	}

}
class Main
{
	String name;
	Main(String nam)
	{
		name=nam;
	
		System.out.println("The name is: "+name);
	
}
}

